# Curios -> Fabric port (1.21.1)

Stage 1 of N. `./gradlew :fabric:build` should succeed (only `common` + skeleton + compat layer).
The original NeoForge module is kept in `./neoforge` as a **reference only** (not in settings.gradle).

## Layout
- `common/`  – unchanged, vanilla-only code (ICurio, ICurioItem, mixins for triggers, ...)
- `fabric/`  – new module (Fabric Loom, Mojang mappings)
  - `compat/bus`   – `CuriosEventBus.BUS` replaces `NeoForge.EVENT_BUS` for Curios API events
  - `compat/items` – IItemHandler, ItemStackHandler, CombinedInvWrapper, SlotItemHandler, ItemHandlerHelper
  - `compat/util`  – INBTSerializable
  - `curios.accesswidener` – converted from accesstransformer.cfg
- Porting rules: `net.neoforged.neoforge.items.*` -> `top.theillusivec4.curios.compat.items.*`,
  `net.neoforged.bus.api.*` -> `top.theillusivec4.curios.compat.bus.*`,
  `NeoForge.EVENT_BUS` -> `CuriosEventBus.BUS`, `TriState` -> `net.fabricmc.fabric.api.util.TriState`,
  `@OnlyIn(Dist.CLIENT)` -> `@Environment(EnvType.CLIENT)`.

## Roadmap
1. [done] Skeleton, build, AW, compat layer, platform service
2. API package (CuriosApi, events, type/*, data) -> move from neoforge/ to fabric/src
3. Registry, config (ModConfigSpec replacement), data managers / reload listeners
4. Inventory: CurioStacksHandler, DynamicStackHandler, CurioSlot, CuriosContainer (ExtendedScreenHandler-style menu)
5. Storage & lookup: capabilities -> Data Attachment API (inventory) + Item API Lookup / registry (ICurio)
6. Networking: PayloadRegistrar -> Fabric Networking (CustomPayload codecs are mostly reusable)
7. Events -> Fabric API callbacks + mixins (drops, xp, enderman anger, equipment change, tick, join, clone)
8. Client: screens, key mapping, render layer, tooltips
9. Commands & selector options
10. Mixins from neoforge/mixin/core
11. JEI / EMI / REI (Fabric artifacts)
