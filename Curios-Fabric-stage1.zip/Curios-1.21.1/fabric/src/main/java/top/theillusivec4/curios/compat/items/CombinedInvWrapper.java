/*
 * Copyright (c) 2018-2024 C4
 *
 * This file is part of Curios, a mod made for Minecraft.
 *
 * Curios is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Curios is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with Curios.  If not, see <https://www.gnu.org/licenses/>.
 *
 */

package top.theillusivec4.curios.compat.items;

import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

/** Exposes several handlers as one contiguous slot range. */
public class CombinedInvWrapper implements IItemHandlerModifiable {

  protected final IItemHandlerModifiable[] itemHandler;
  protected final int[] baseIndex;
  protected final int slotCount;

  public CombinedInvWrapper(IItemHandlerModifiable... itemHandler) {
    this.itemHandler = itemHandler;
    this.baseIndex = new int[itemHandler.length];
    int index = 0;

    for (int i = 0; i < itemHandler.length; i++) {
      index += itemHandler[i].getSlots();
      this.baseIndex[i] = index;
    }
    this.slotCount = index;
  }

  protected int getIndexForSlot(int slot) {

    if (slot < 0) {
      return -1;
    }

    for (int i = 0; i < this.baseIndex.length; i++) {

      if (slot - this.baseIndex[i] < 0) {
        return i;
      }
    }
    return -1;
  }

  protected IItemHandlerModifiable getHandlerFromIndex(int index) {

    if (index < 0 || index >= this.itemHandler.length) {
      return EmptyHandler.INSTANCE;
    }
    return this.itemHandler[index];
  }

  protected int getSlotFromIndex(int slot, int index) {

    if (index <= 0 || index >= this.baseIndex.length) {
      return slot;
    }
    return slot - this.baseIndex[index - 1];
  }

  @Override
  public void setStackInSlot(int slot, @NotNull ItemStack stack) {
    int index = this.getIndexForSlot(slot);
    this.getHandlerFromIndex(index).setStackInSlot(this.getSlotFromIndex(slot, index), stack);
  }

  @Override
  public int getSlots() {
    return this.slotCount;
  }

  @Override
  @NotNull
  public ItemStack getStackInSlot(int slot) {
    int index = this.getIndexForSlot(slot);
    return this.getHandlerFromIndex(index).getStackInSlot(this.getSlotFromIndex(slot, index));
  }

  @Override
  @NotNull
  public ItemStack insertItem(int slot, @NotNull ItemStack stack, boolean simulate) {
    int index = this.getIndexForSlot(slot);
    return this.getHandlerFromIndex(index)
        .insertItem(this.getSlotFromIndex(slot, index), stack, simulate);
  }

  @Override
  @NotNull
  public ItemStack extractItem(int slot, int amount, boolean simulate) {
    int index = this.getIndexForSlot(slot);
    return this.getHandlerFromIndex(index)
        .extractItem(this.getSlotFromIndex(slot, index), amount, simulate);
  }

  @Override
  public int getSlotLimit(int slot) {
    int index = this.getIndexForSlot(slot);
    return this.getHandlerFromIndex(index).getSlotLimit(this.getSlotFromIndex(slot, index));
  }

  @Override
  public boolean isItemValid(int slot, @NotNull ItemStack stack) {
    int index = this.getIndexForSlot(slot);
    return this.getHandlerFromIndex(index).isItemValid(this.getSlotFromIndex(slot, index), stack);
  }

  private static final class EmptyHandler implements IItemHandlerModifiable {

    private static final EmptyHandler INSTANCE = new EmptyHandler();

    @Override
    public void setStackInSlot(int slot, @NotNull ItemStack stack) {
    }

    @Override
    public int getSlots() {
      return 0;
    }

    @Override
    @NotNull
    public ItemStack getStackInSlot(int slot) {
      return ItemStack.EMPTY;
    }

    @Override
    @NotNull
    public ItemStack insertItem(int slot, @NotNull ItemStack stack, boolean simulate) {
      return stack;
    }

    @Override
    @NotNull
    public ItemStack extractItem(int slot, int amount, boolean simulate) {
      return ItemStack.EMPTY;
    }

    @Override
    public int getSlotLimit(int slot) {
      return 0;
    }

    @Override
    public boolean isItemValid(int slot, @NotNull ItemStack stack) {
      return false;
    }
  }
}
