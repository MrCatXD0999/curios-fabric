/*
 * Copyright (c) 2018-2024 C4
 *
 * This file is part of Curios, a mod made for Minecraft.
 *
 * Curios is free software: you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Curios is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with Curios.  If not, see <https://www.gnu.org/licenses/>.
 *
 */

package top.theillusivec4.curios.compat.bus;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import top.theillusivec4.curios.CuriosConstants;

/**
 * Minimal event bus that stands in for {@code NeoForge.EVENT_BUS}.
 * <p>
 * It carries the events of the Curios API (CurioCanEquipEvent, CurioChangeEvent, DropRulesEvent,
 * ...), so that addons can keep the same listener-based API. Vanilla / Fabric API hooks are
 * <b>not</b> routed through here, they call Curios code directly.
 */
public final class CuriosEventBus {

  /** Equivalent of {@code NeoForge.EVENT_BUS}. */
  public static final CuriosEventBus BUS = new CuriosEventBus();

  private record Listener(Object owner, Class<?> type, EventPriority priority,
                          boolean receiveCanceled, Consumer<Object> handler) {

  }

  private final List<Listener> listeners = new CopyOnWriteArrayList<>();

  private CuriosEventBus() {
  }

  @SuppressWarnings("unchecked")
  public <T extends Event> void addListener(Class<T> type, Consumer<T> handler) {
    this.addListener(EventPriority.NORMAL, false, type, handler);
  }

  public <T extends Event> void addListener(EventPriority priority, Class<T> type,
                                            Consumer<T> handler) {
    this.addListener(priority, false, type, handler);
  }

  @SuppressWarnings("unchecked")
  public <T extends Event> void addListener(EventPriority priority, boolean receiveCanceled,
                                            Class<T> type, Consumer<T> handler) {
    this.insert(new Listener(handler, type, priority, receiveCanceled, e -> handler.accept((T) e)));
  }

  /** Registers every {@link SubscribeEvent}-annotated method of the object (or class). */
  public void register(Object target) {
    boolean isStatic = target instanceof Class<?>;
    Class<?> clazz = isStatic ? (Class<?>) target : target.getClass();

    for (Class<?> c = clazz; c != null && c != Object.class; c = c.getSuperclass()) {

      for (Method method : c.getDeclaredMethods()) {
        SubscribeEvent annotation = method.getAnnotation(SubscribeEvent.class);

        if (annotation == null) {
          continue;
        }

        if (method.getParameterCount() != 1 ||
            !Event.class.isAssignableFrom(method.getParameterTypes()[0])) {
          CuriosConstants.LOG.error("Invalid @SubscribeEvent method {}", method);
          continue;
        }

        if (isStatic != Modifier.isStatic(method.getModifiers())) {
          continue;
        }
        method.setAccessible(true);
        Object instance = isStatic ? null : target;
        this.insert(new Listener(target, method.getParameterTypes()[0], annotation.priority(),
            annotation.receiveCanceled(), e -> {
          try {
            method.invoke(instance, e);
          } catch (ReflectiveOperationException ex) {
            throw new RuntimeException("Error invoking event listener " + method, ex);
          }
        }));
      }
    }
  }

  public void unregister(Object target) {
    this.listeners.removeIf(l -> l.owner == target);
  }

  public <T extends Event> T post(T event) {

    for (Listener listener : this.listeners) {

      if (!listener.type.isInstance(event)) {
        continue;
      }

      if (event.isCanceledInternal() && !listener.receiveCanceled) {
        continue;
      }
      listener.handler.accept(event);
    }
    return event;
  }

  private synchronized void insert(Listener listener) {
    List<Listener> copy = new ArrayList<>(this.listeners);
    int index = copy.size();

    // stable insertion: after every listener of the same or a higher priority
    for (int i = 0; i < copy.size(); i++) {

      if (copy.get(i).priority.ordinal() > listener.priority.ordinal()) {
        index = i;
        break;
      }
    }
    copy.add(index, listener);
    this.listeners.clear();
    this.listeners.addAll(copy);
  }
}
